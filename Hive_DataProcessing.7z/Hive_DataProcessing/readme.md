some is custom developed code with unit test cases.
Some code is referenced from :

https://www.youtube.com/watch?v=uoS3opInXec&t=364s
https://github.com/dgadiraju/code/tree/master/simple-spark-project

https://github.com/jleetutorial

