package com.eva.am.process

import java.util

import com.eva.am.process.filesreader.{HDFSReader, TitanHDFSReader}
import org.apache.spark.SparkContext
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.junit.{Assert, Test}
import org.scalatest._
import org.slf4j.LoggerFactory
import org.scalamock.scalatest.MockFactory
import org.scalatest.mock.MockitoSugar
import org.mockito.Mockito._
import org.junit.Assert.assertEquals
import org.mockito.Mockito.mock
import org.mockito.Mockito.when
import org.junit.runner.RunWith
import org.mockito.Matchers
import org.mockito.runners.MockitoJUnitRunner
import org.scalatest.junit.JUnitRunner
import org.scalatest.mockito.MockitoSugar

/**
  * Created by ${Brijesh_Jaggi} on 2018/03/27.
  */
//@RunWith(classOf[MockitoJUnitRunner])
class HivePartitionORCTest  extends FunSpec with MockitoSugar  {

  val FILE_NAMES_LIST_TO_GROUP = List("MILVUS_CustomerAccountDetailDelta_20171207000000_0001.json",
    "hdfs://uat/account.json",
    "MILVUS_PortfolioDetailDelta_20180104000000_0002.json",
    "MILVUS_AssetHoldingDetailDaily_20180327081339_0002.json",
    "MILVUS_SummaryMarketValuationDaily_20180326083412_0004.json"
  )



/*
 val sparkSession: SparkSession = SparkSession.builder().appName("test").master("local[3]").config("spark.hadoop.validateOutputSpecs", "false").getOrCreate()
  val sc = sparkSession.sparkContext
  val sqlContext = sparkSession.sqlContext
  protected final val logger = LoggerFactory.getLogger(this.getClass)
*/


//  @Test
  it ("Group all files bases on names") {


  Assert.assertTrue(true);
    /*val reader = mock[TitanHDFSReader]
    val sc = mock[SparkContext]
    val session = mock[SparkSession]
    when(reader.readFilesFromFolder(session,sc,"")).thenReturn(FILE_NAMES_LIST_TO_GROUP)
 /*   when(sc.wholeTextFiles("").thenReturn(sc.parallelize(List(
      ("I", "India"),
      ("U", "USA"),
      ("W", "West"))))*/
    println(" ====> "+reader.readFilesFromFolder(session,sc,""))*/


  }






}

