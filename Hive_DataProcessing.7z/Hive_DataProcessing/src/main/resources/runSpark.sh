#!/bin/bash

spark-submit --class com.eva.am.process.HivePartitionORC /tmp/one-hive_2.11-1.0.jar --master local[*] --principal DABCDSRV26H --keytab $/app//ABCD/hadoop/DABCDSRV26H.service.keytab --jars /tmp/one-hive_2.11-1.0.jar



SPARK_HOME/bin/spark-submit \
--class com.one.am.process.HivePartitionORC \
--master yarn \
--deploy-mode client \
--driver-memory 2g \
--executor-memory 2g \
--executor-cores 1 \
--files DABCDSRV.keytab \
/tmp/one-hive_2.11-1.0.jar



echo -e "\n[INFO]: Start running spark"
${SPARK_HOME}/bin/spark-submit -v --master yarn --deploy-mode client --driver-memory 8G --executor-memory 24G --queue ${YARN_QUEUE_NAME} \
--principaKERBEROS_KEYTAB_LOCATIONl ${KERBEROS_PRINCIPAL} \
--keytab ${}/${KERBEROS_KEYTAB} \
--jars /tmp/one-hive_2.11-1.0.jar \
--files ${HBASE_CONFIG_LOCATION}/hbase-site.xml,${HBASE_CONFIG_LOCATION}/core-site.xml,${HBASE_CONFIG_LOCATION}/hdfs-site.xml,${HBASE_CONFIG_LOCATION}/krb5.conf,${HBASE_CONFIG_LOCATION}/${KERBEROS_KEYTAB} \
--driver-class-path ${DEPLOY_LIB_HOME}/seclending_analytics-assembly-${ARTIFACT_VERSION}.jar \
--conf "spark.driver.maxResultSize=0" --conf "spark.logConf=true" --conf "spark.executor.instances=10" \
--driver-java-options "-Dlog4j.configuration=${LOG4J_PROPERTY_LOCATION}" \
--class com..ABCD.Driver ${DEPLOY_LIB_HOME}/seclending_analytics-assembly-${ARTIFACT_VERSION}.jar ${DEPLOY_CONF_HOME}/${SPARK_JOB_CONF_FILE} ${MILVUS_DATE} > /dev/null &

echo -e "\n[INFO]: Spark running"
