package com.eva.am.process.filesreader

/**
  * Created by ${Brijesh_Jaggi} on 2018/03/27.
  */
object HDFSFileDAO {

}
