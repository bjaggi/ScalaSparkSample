package com.eva.am.process.filesreader

import com.eva.am.filecategorymapper.MilvusMapper
import com.eva.am.process.constants.MilvusEntity
import com.eva.am.process.fileswriter.HdfsPartitionWriter
import com.eva.am.process.logger.HiveProcessorLogger
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkContext
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.slf4j.LoggerFactory

import scala.collection.immutable.List
import scala.collection.mutable.Map
import scala.reflect.io.File

/**
  * Created by ${Brijesh_Jaggi} on 2018/03/27.
  */
object TitanHDFSReader extends HDFSReader {

  //private val logger = HiveProcessorLogger.hiveProcessorLogger
  protected val logger = LoggerFactory.getLogger(this.getClass)


  /**
    *
    * @param session
    * @param sparkContext
    * @param readFromPath
    * @param saveToPath
    * @return
    */
  def readFilesFromFolder(session: SparkSession, sparkContext: SparkContext, readFromPath: String, saveToPath: String)  {
    val filesInFolder = FileSystem.get(sparkContext.hadoopConfiguration).listStatus(new Path(readFromPath))
    // -- Loop through each file and call the function 'categorizeFile'
    filesInFolder.foreach(filename => {
     // val fileName = filename.getPath.getName
      val fileName = filename.getPath.toString
      categorizeFile(fileName)
    })
    logger.info(s"Files Have been Categorized to : ${MilvusMapper.mapCategoryFiles}")
    for ((catrgory, filespercategory) <- MilvusMapper.mapCategoryFiles) {
      println(s" Output Of Mapper ::: key value:  $catrgory $filespercategory")
      //val portfolioDtlRDD = session.read.json("/uat/MILVUS_PortfolioDetailDelta_20180315000000_0002.json")
      for(file <- filespercategory ) {
        println(s" Attempting to read and write file $file ")
          val portfolioDtlRDD = session.read.json(file)
          catrgory match {
            case MilvusEntity.CustomerAccount => HdfsPartitionWriter(MilvusEntity.CustomerAccount).writeToHdfs(session, file)
            case MilvusEntity.AccountCash => HdfsPartitionWriter(MilvusEntity.AccountCash).writeToHdfs(session, file)
            case _ => println("Error Junk File Found")
          }



      }
    }

    //val portfolioDtlRDD = session.read.json("/uat/employee.json")
    //portfolioDtlRDD.printSchema()


   /* portfolioDtlRDD
      .write
      //.format("com.databricks.spark.csv")
      .partitionBy("Change_Type")
      // .format("orc")
      //.format("parquet")
      //.option("orc.compress", "snappy")
      .mode(SaveMode.Overwrite)
      // .option("header", "true")
      //.insertInto("Account_Table")
      //.save(OUTPUT_FOLDER)
      .save(saveToPath)
    //.parquet("/uat/ORC_TEST_JAGGI")
    //.orc("/uat/ORC_TEST_JAGGI")

*/
  }

  /**
    *
    * @param file
    * @return
    */
  def categorizeFile(file: String): Map[String, List[String]] = {
    file match{
      case inputFileName if inputFileName.contains(MilvusEntity.CustomerAccount) => {
        appendToMap(MilvusEntity.CustomerAccount,file)
      }
      case inputFileName if inputFileName.contains(MilvusEntity.AccountCash) => {
        appendToMap(MilvusEntity.AccountCash,file)
      }
      case _ => {
        appendToMap("Junk",file)
      }

    }

    MilvusMapper.mapCategoryFiles
  }

  /**
    *
    * @param file
    * @param category
    */
  def appendToMap(  category: String, file: String): List[String] ={
    var list : List[String] = null
    if(MilvusMapper.mapCategoryFiles.get(category).isEmpty)
      list = List(file)
    else{
      list = MilvusMapper.mapCategoryFiles.get(category).toList.flatten
      list = file :: list
    }
    MilvusMapper.mapCategoryFiles += (category -> list)
    list
  }


}
