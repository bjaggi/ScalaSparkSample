package com.eva.am.process.properties

/**
  * Created by ${Brijesh_Jaggi} on 2018/04/03.
  */
case class MilvusProperties  (
                               customerAccountInputFolder : String,
                               customerAccountOutputFolder : String ,
                               customerAccountPartitionColumns : String,

                               accountCashInputFolder : String,
                               accountCashOutputFolder : String ,
                               accountCashPartitionColumns : String

                             )
