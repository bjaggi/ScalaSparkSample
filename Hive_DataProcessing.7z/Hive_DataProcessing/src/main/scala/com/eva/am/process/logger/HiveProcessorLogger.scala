package com.eva.am.process.logger

/**
  * Created by ${Brijesh_Jaggi} on 2018/04/04.
  */

import org.slf4j.Logger
import org.slf4j.LoggerFactory


object HiveProcessorLogger {
  var hiveProcessorLogger: Logger = LoggerFactory.getLogger("rootLogger")
  var endUserLogger: Logger = LoggerFactory.getLogger("endUserLogger")
}

