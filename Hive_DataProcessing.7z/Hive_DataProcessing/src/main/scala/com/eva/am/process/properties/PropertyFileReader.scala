package com.eva.am.process.properties
import java.io.{File, FileInputStream}
import java.nio.file.Files
import java.util.Properties

import scala.util.Properties
import scala.io.Source.fromURL

/**
  * Created by ${Brijesh_Jaggi} on 2018/04/02.
  */
object PropertyFileReader {

  var milvusProperties : MilvusProperties = null;

  def read(): Unit = {

    val resourceName = "hiveloader.properties"
    // could also be a constant
    val loader = Thread.currentThread.getContextClassLoader
    val props = new Properties

      val resourceStream = loader.getResourceAsStream(resourceName)
      try( props.load(resourceStream))

         milvusProperties = MilvusProperties.apply(
           //Mapped CustomerAccount entries from property file
          props.get("customeraccount.input.folder").toString,
          props.get("customeraccount.output.folder").toString,
          props.get("customeraccount.partition.columns").toString,

           //Mapped AccountCash entries from property file
           props.get("accountcash.input.folder").toString,
           props.get("accountcash.output.folder").toString,
           props.get("accountcash.partition.columns").toString

         )


        println(milvusProperties.customerAccountInputFolder)
        println(milvusProperties.customerAccountOutputFolder)
        println(milvusProperties.customerAccountPartitionColumns)

    }
}
