package com.eva.am.process.filesreader

import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession

/**
  * Created by ${Brijesh_Jaggi} on 2018/03/27.
  */
trait HDFSReader {

  def readFilesFromFolder(session: SparkSession,sparkContext : SparkContext, readFromPath: String, saveToPath: String )
}
