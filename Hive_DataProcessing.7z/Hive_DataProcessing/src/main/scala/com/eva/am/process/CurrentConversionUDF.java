package com.eva.am.process;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;


@Description(
        name="SimpleUDFExample",
        value="returns 'hello x', where x is whatever you give it (STRING)",
        extended="SELECT simpleudfexample('world') from foo limit 1;"
)

/**
 * Created by ${Brijesh_Jaggi} on 2018/01/05.
 */
public class CurrentConversionUDF extends UDF {

    public Text evaluate(Text input) {
        return new Text("Hello " + input.toString());
    }
}
