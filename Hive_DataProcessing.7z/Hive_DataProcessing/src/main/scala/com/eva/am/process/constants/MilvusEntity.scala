package com.eva.am.process.constants

/**
  * Created by ${Brijesh_Jaggi} on 2018/04/02.
  */
object MilvusEntity {

  val CustomerAccount = "CustomerAccountDetailDelta"
  val AccountCash = "AccountCashDetailDaily"

}
