package com.eva.am.process.fileswriter

import com.eva.am.process.constants.MilvusEntity
import com.eva.am.process.properties.PropertyFileReader
import org.apache.spark.sql.{SaveMode, SparkSession}

/**
  * Created by ${Brijesh_Jaggi} on 2018/04/02.
  */

trait HdfsPartitionWriter{
  def writeToHdfs(session : SparkSession, filename: String)
  def getpartitions : String
  def getOutPutFolder : String
}
object HdfsPartitionWriter {

  private class CustomerAccountWriter extends HdfsPartitionWriter{

    override def writeToHdfs(session: SparkSession, filename: String): Unit = {


      val portfolioDtlRDD = session.read.json(filename)
      portfolioDtlRDD
        .write
        //.format("com.databricks.spark.csv")
        .partitionBy(getpartitions)
        // .format("orc")
        //.format("parquet")
        //.option("orc.compress", "snappy")
        .mode(SaveMode.Overwrite)
        // .option("header", "true")
        //.insertInto("EMPLOYEE_TABLE")
        //.save(OUTPUT_FOLDER)
        .save(getOutPutFolder)
      //.parquet("/uat/INGESTION/ORC_TEST_JAGGI")
      //.orc("/uat/INGESTION/ORC_TEST_JAGGI")

    }

    override def getOutPutFolder: String = {
       // hardcoded now but get from a  property files
     //"/uat/data/standardized/"
      PropertyFileReader.milvusProperties.customerAccountOutputFolder
    }

    override def getpartitions: String = {
      //columns to partition on
      PropertyFileReader.milvusProperties.customerAccountPartitionColumns
    }
  }


  private class AccountCashWriter extends HdfsPartitionWriter {
    override def writeToHdfs(session: SparkSession, filename: String): Unit = {
      val fileRDD = session.read.json(filename)
      fileRDD
        .write
        .partitionBy(getpartitions)
        .mode(SaveMode.Overwrite)
        .save(getOutPutFolder)
    }

    override def getOutPutFolder:String = {
      PropertyFileReader.milvusProperties.accountCashOutputFolder
    }

    override def getpartitions: String = {
      PropertyFileReader.milvusProperties.accountCashPartitionColumns
    }

  }


  //  'factory' method
  def apply(s: String):HdfsPartitionWriter = {
    if (s == MilvusEntity.CustomerAccount)
      return new CustomerAccountWriter
    else if ( s == MilvusEntity.AccountCash )
      return new AccountCashWriter
    else
      return  throw new IllegalArgumentException(" Not ready for this argument yet!")

  }


}
