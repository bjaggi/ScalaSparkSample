package com.eva.am.filecategorymapper

import scala.collection.immutable.List
import scala.collection.mutable.Map

/**
  * Created by ${Brijesh_Jaggi} on 2018/04/03.
  */
object MilvusMapper {
  val mapCategoryFiles = Map[String, List[String]]()

}
