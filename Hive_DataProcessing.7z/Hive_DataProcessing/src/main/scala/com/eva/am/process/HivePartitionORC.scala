package com.eva.am.process

import java.io.File

import com.eva.am.process.constants.MilvusEntity
import com.eva.am.process.filesreader.TitanHDFSReader
import com.eva.am.process.properties.{MilvusProperties, PropertyFileReader}
import com.typesafe.config.ConfigFactory
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.hive.HiveContext
import org.scalacheck.Prop.Exception
import org.slf4j.LoggerFactory

import scala.sys.process.Process
import scala.util.Try

/**
  * Created by ${Brijesh_Jaggi} on 2018/03/23.
  */
object HivePartitionORC {
  protected val logger = LoggerFactory.getLogger(this.getClass)

  def main(args: Array[String]) {
    //System.setProperty("hadoop.home.dir", "C:\\Softwares\\Winutils")
    val conf = new SparkConf().setAppName("HiveORCPartition").setMaster("local[*]").set("spark.sql.crossJoin.enabled", "true")
    var readFromFolderPath: String =""
    var saveToFolderPath : String=""
    logger.info("Starting Milvus Hive Partition Job ")
    if(args.length == 2) {
      //readFromFolderPath = args(0)
      //saveToFolderPath = args(1)
      readFromFolderPath = PropertyFileReader.milvusProperties.customerAccountInputFolder
      saveToFolderPath = PropertyFileReader.milvusProperties.customerAccountInputFolder

        Option(readFromFolderPath).getOrElse( throw new IllegalArgumentException("Read From Folder cannot be null"))
      Option(saveToFolderPath).getOrElse( throw new IllegalArgumentException("Save To Folder cannot be null"))
      PropertyFileReader.read()

    } else {
      throw new IllegalArgumentException("Send HDFS Input-Read-Folder and Output-Read-Folder as arguments")
    }


    // Get Spark Session
    val session = SparkSession.builder().
      appName("AM_CDRFiles_Processor").
      config("spark.sql.crossJoin.enabled", "true").
      master("local[*]").
    //enableHiveSupport().
    getOrCreate()


    // Start Processing
    TitanHDFSReader.readFilesFromFolder(session,session.sparkContext,readFromFolderPath, saveToFolderPath)

  }


  def readConfiguration(args: Array[String]) = Try(args(0)).toOption match {
    case Some(x) => x.trim.toLowerCase match {
      case "local" => ConfigFactory.load("local.conf")
      case "cluster" => ConfigFactory.load("cluster.conf")
      case _ => ConfigFactory.parseFile(new File(x)).resolve()
    }
    case None => ConfigFactory.load()
  }

}

