

object HelloWorld {
  
  def main(args: Array[String]): Unit = {
    print("Hello")
  }

}